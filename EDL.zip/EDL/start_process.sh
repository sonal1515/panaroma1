#!/bin/bash

cd Desktop
python3 take_input.py